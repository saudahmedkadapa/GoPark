// src/components/ComplexDashboard.js
// import React from 'react';
import React, { useEffect, useState } from 'react';
import { useTable } from 'react-table';
import './ComplexDashboard .css'; // Corrected CSS import
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import axios from 'axios'; 

// const ComplexDashboard = ({ data = [
//     { complexName: 'Complex A', total_parking_levels: '1' },
//     { complexName: 'Complex B', total_parking_levels: '2'},
//     //{ levelID: '3', complexName: 'Complex C', levelNumber: '3', capacity: 200, availableSlot: 50, totalSlot: 250 },
// ] }) => {
//   const navigate = useNavigate(); // Initialize useNavigate



const ComplexDashboard = () => {
  const [data, setData] = useState([]);
  const navigate = useNavigate(); // Initialize useNavigate
  

  useEffect(() => {
    const complexId = localStorage.getItem('complexId');
    //if (complexId) {
       // axios.get(`http://localhost:8282/api/getcomplex/${complexId}`)
       axios.get(`http://localhost:8282/api/getcomplexes`)
            .then(response => {
              console.log(data);
                setData(response.data); // Ensure the data is in an array if required by the table
            })
            .catch(error => {
                console.error("There was an error fetching the data!", error);
            });
    //} else {
        //console.error("No complexId found in local storage");
   // }
}, []);



  const columns = React.useMemo(
    () => [
      // { Header: 'LevelID', accessor: 'levelID' },
      { Header: 'Complex Name', accessor: 'complexName' },
      { Header: 'Complex Address', accessor: 'complexAddress' },
      { Header: 'Total Parking Levels', accessor: 'totalParkingLevels' },

      //{ Header: 'Capacity', accessor: 'capacity' },
      // { Header: 'Available Slot', accessor: 'availableSlot' },
      // { Header: 'Total Slot', accessor: 'totalSlot' },
      // {
      //   Header: 'Actions',
      //   accessor: 'actions',
      //   Cell: ({ row }) => (
      //     <button onClick={() => handleViewSlots(row.original.totalParkingLevels)}>
      //       View Slots
      //     </button>
      //   ),
      // },
    ],
    []
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow
  } = useTable({ columns, data });

  // Corrected handleViewSlots function
  // const handleViewSlots = (totalParkingLevels) => {
  //   navigate(`/grid/${totalParkingLevels}`); // Navigate to SlotGrid with levelID
  // };

  return (
    <table {...getTableProps()} className="complex-dashboard-table">
      <thead>
        {headerGroups.map(headerGroup => (
          <tr {...headerGroup.getHeaderGroupProps()} key={headerGroup.id}>
            {headerGroup.headers.map(column => (
              <th {...column.getHeaderProps()} key={column.id}>
                {column.render('Header')}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map(row => {
          prepareRow(row);
          return (
            <tr {...row.getRowProps()} key={row.id}>
              {row.cells.map(cell => (
                <td {...cell.getCellProps()} key={cell.column.id}>
                  {cell.render('Cell')}
                </td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default ComplexDashboard;
