package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.beans.ParkingUser;
import com.demo.dao.ParkingUserRepository;

@Service
public class ParkingUserServiceImpl implements ParkingUserService {

    @Autowired
    private ParkingUserRepository parkingUserRepository;

    @Override
    public List<ParkingUser> getAllUsers() {
        return parkingUserRepository.findAll();
    }

    @Override
    public ParkingUser getUserById(int userId) {
        return parkingUserRepository.findById(userId).orElse(null);
    }

    @Override
    public ParkingUser saveUser(ParkingUser user) {
        return parkingUserRepository.save(user);
    }

    @Override
    public void deleteUserById(int userId) {
        parkingUserRepository.deleteById(userId);
    }
}
