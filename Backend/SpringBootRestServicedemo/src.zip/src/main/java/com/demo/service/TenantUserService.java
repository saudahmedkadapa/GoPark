package com.demo.service;

import java.util.List;

import com.demo.beans.TenantUser;

public interface TenantUserService {
    TenantUser saveTenantUser(TenantUser tenantUser);
    TenantUser getTenantUserById(int id);
    List<TenantUser> getAllTenantUsers();
    void deleteTenantUser(int id);
}
