package com.demo.service;


import java.util.List;

import com.demo.beans.ParkingUser;

public interface ParkingUserService {
    List<ParkingUser> getAllUsers();
    ParkingUser getUserById(int userId);
    ParkingUser saveUser(ParkingUser user);
    void deleteUserById(int userId);
}
