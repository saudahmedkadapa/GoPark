package com.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.beans.ParkingUserBooking;
import com.demo.dao.ParkingUserBookingRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ParkingUserBookingServiceImpl implements ParkingUserBookingService {

    @Autowired
    private ParkingUserBookingRepository bookingRepository;

    @Override
    public ParkingUserBooking saveBooking(ParkingUserBooking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public Optional<ParkingUserBooking> findBookingById(Integer bookingId) {
        return bookingRepository.findById(bookingId);
    }

    @Override
    public List<ParkingUserBooking> findAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public void deleteBooking(Integer bookingId) {
        bookingRepository.deleteById(bookingId);
    }
}

