package com.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.beans.Company;

	
	@Repository
	public interface CompanyDao extends JpaRepository<Company, Integer> {
	    // Additional query methods can be defined here
	}


